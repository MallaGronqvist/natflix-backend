-- Adminer 4.8.1 MySQL 8.0.31 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `authorities`;
CREATE TABLE `authorities` (
  `username` varchar(50) NOT NULL,
  `authority` varchar(50) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `authorities` (`username`, `authority`) VALUES
('edward@example.com',	'ROLE_USER'),
('henry@example.com',	'ROLE_USER'),
('max@example.com',	'ROLE_USER'),
('mike@example.com',	'ROLE_USER'),
('sally@example.com',	'ROLE_USER'),
('sheela@example.com',	'ROLE_USER');

DROP TABLE IF EXISTS `content`;
CREATE TABLE `content` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `type_id` int DEFAULT NULL,
  `category_id` int DEFAULT NULL,
  `summary` text,
  `logo_url` text,
  `banner_url` text,
  `thumbnail_url` text,
  PRIMARY KEY (`id`),
  KEY `type_id` (`type_id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `content_ibfk_1` FOREIGN KEY (`type_id`) REFERENCES `content_type` (`id`),
  CONSTRAINT `content_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `content_category` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `content` (`id`, `title`, `type_id`, `category_id`, `summary`, `logo_url`, `banner_url`, `thumbnail_url`) VALUES
(96,	'Tom Hanks is Forrest Gump',	2,	4,	'Tom Hanks plays Forrest Gump...',	'http://localhost:8000/files/1666861555764.png',	'http://localhost:8000/files/1666861555784.png',	'http://localhost:8000/files/1666861555788.png'),
(97,	'Enola Holmes',	2,	2,	'Young amatour detective goes to village...',	'http://localhost:8000/files/1666861819661.png',	'http://localhost:8000/files/1666861819682.png',	'http://localhost:8000/files/1666861819685.png'),
(98,	'Forever Rich',	2,	4,	'Hip hop, drugs and cash...',	'http://localhost:8000/files/1666861929159.png',	'http://localhost:8000/files/1666861929180.png',	'http://localhost:8000/files/1666861929184.png'),
(99,	'Love Death Robots',	2,	2,	'Robots take over and fall in love...but then comes death...',	'http://localhost:8000/files/1666862069002.png',	'http://localhost:8000/files/1666862069017.png',	'http://localhost:8000/files/1666862069019.png'),
(100,	'Anikulapo',	2,	4,	'Anikulapo village gets a new leader from a foreign galaxy...',	'http://localhost:8000/files/1666862297119.png',	'http://localhost:8000/files/1666862297134.png',	'http://localhost:8000/files/1666862297138.png'),
(101,	'Christmas Wedding Planner',	2,	3,	'Rose plans a fantastic wedding at Christmas.',	'http://localhost:8000/files/1666862438809.png',	'http://localhost:8000/files/1666862438822.png',	'http://localhost:8000/files/1666862438825.png'),
(102,	'Monster Harmon',	2,	4,	'Harmon is accused of being a monster.',	'http://localhost:8000/files/1666862543162.png',	'http://localhost:8000/files/1666862543174.png',	'http://localhost:8000/files/1666862543177.png'),
(103,	'1922',	2,	4,	'A dark story about running away from...',	'http://localhost:8000/files/1666862778336.png',	'http://localhost:8000/files/1666862778352.png',	'http://localhost:8000/files/1666862778355.png'),
(104,	'Boys in the Hood',	3,	5,	'The story of the boys in the hood and their mother.',	'http://localhost:8000/files/1666863131322.png',	'http://localhost:8000/files/1666863131338.png',	'http://localhost:8000/files/1666863131341.png'),
(105,	'Alive',	3,	5,	'A documentary about a hastag and some influencers....',	'http://localhost:8000/files/1666863229522.png',	'http://localhost:8000/files/1666863229538.png',	'http://localhost:8000/files/1666863229543.png'),
(106,	'Centauro',	3,	5,	'The story about the motor racer who won the Spanish cup...',	'http://localhost:8000/files/1666863363980.png',	'http://localhost:8000/files/1666863363991.png',	'http://localhost:8000/files/1666863363993.png'),
(107,	'DC Titans',	1,	2,	'Cool titans fighting and racing...',	'http://localhost:8000/files/1666863482388.png',	'http://localhost:8000/files/1666863482404.png',	'http://localhost:8000/files/1666863482407.png'),
(108,	'The A List',	1,	4,	'Teenagers in high school keep their own a list over class mates.',	'http://localhost:8000/files/1666863861466.png',	'http://localhost:8000/files/1666863861482.png',	'http://localhost:8000/files/1666863861493.png'),
(109,	'Snabba Cash',	1,	2,	'Criminals want to get rich so they rob a bank...',	'http://localhost:8000/files/1666864293487.png',	'http://localhost:8000/files/1666864293501.png',	'http://localhost:8000/files/1666864293510.png'),
(110,	'All of us are dead',	1,	1,	'All zombies come back from their graves.',	'http://localhost:8000/files/1666865377653.png',	'http://localhost:8000/files/1666865377680.png',	'http://localhost:8000/files/1666865377683.png'),
(111,	'Dinotrux',	1,	2,	'Dinosaur lego animation where beasts meat and...',	'http://localhost:8000/files/1666865454128.png',	'http://localhost:8000/files/1666865454141.png',	'http://localhost:8000/files/1666865454145.png'),
(112,	'Fauda',	1,	2,	'Fauda decides to join the war.',	'http://localhost:8000/files/1666865545767.png',	'http://localhost:8000/files/1666865545788.png',	'http://localhost:8000/files/1666865545791.png'),
(113,	'Drishyam',	1,	3,	'Drishyam is a family father with many ideas...',	'http://localhost:8000/files/1666865589841.png',	'http://localhost:8000/files/1666865589852.png',	'http://localhost:8000/files/1666865589855.png'),
(114,	'Holiday in the wild',	1,	4,	'Max goes on a holiday in the wild and gets lost.',	'http://localhost:8000/files/1666865639758.png',	'http://localhost:8000/files/1666865639769.png',	'http://localhost:8000/files/1666865639771.png'),
(115,	'Toskana',	3,	5,	'A beautiful documentary of the Italian Tuscony reagon...',	'http://localhost:8000/files/1666871059873.png',	'http://localhost:8000/files/1666871059909.png',	'http://localhost:8000/files/1666871059913.png'),
(116,	'The valley of a thousand hills',	3,	5,	'Casey livs in the valley of thousand hills and tries to make a living...',	'http://localhost:8000/files/1666871140335.png',	'http://localhost:8000/files/1666871140357.png',	'http://localhost:8000/files/1666871140361.png'),
(117,	'Nairobi half life',	3,	4,	'A documentary about Nairobi streets.',	'http://localhost:8000/files/1666871184992.png',	'http://localhost:8000/files/1666871185007.png',	'http://localhost:8000/files/1666871185013.png');

DROP TABLE IF EXISTS `content_category`;
CREATE TABLE `content_category` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `content_category` (`id`, `category`) VALUES
(1,	'Horror'),
(2,	'Action'),
(3,	'Comedy'),
(4,	'Drama'),
(5,	'Other');

DROP TABLE IF EXISTS `content_type`;
CREATE TABLE `content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `content_type` (`id`, `type`) VALUES
(1,	'tv-series'),
(2,	'movie'),
(3,	'documentary');

DROP TABLE IF EXISTS `details_films`;
CREATE TABLE `details_films` (
  `id` int NOT NULL AUTO_INCREMENT,
  `content_id` int NOT NULL,
  `video_code` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `content_id` (`content_id`),
  CONSTRAINT `details_films_ibfk_1` FOREIGN KEY (`content_id`) REFERENCES `content` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `details_films` (`id`, `content_id`, `video_code`) VALUES
(54,	96,	'1XRmhoGwgVg'),
(55,	97,	'1d0Zf9sXlHk'),
(56,	98,	'W5T7AOBdgoQ'),
(57,	99,	'wUFwunMKa4E'),
(58,	100,	'rXIKrHPaB-o'),
(59,	101,	'HS9x40rE5Cs'),
(60,	102,	'ykU6SR9HULE'),
(61,	103,	'3E_fT0aTsjI'),
(62,	104,	'aCEjVC3Dtn8'),
(63,	105,	'jQ8CCg1tOqc'),
(64,	106,	'p8CXKceGvAo'),
(66,	115,	'7aNxp7ybmX8'),
(67,	116,	'yS75BhtWwHA'),
(68,	117,	'PfkDonOvZQ8');

DROP TABLE IF EXISTS `details_series`;
CREATE TABLE `details_series` (
  `id` int NOT NULL AUTO_INCREMENT,
  `content_id` int NOT NULL,
  `season_number` int DEFAULT NULL,
  `episode_number` int DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `summary` varchar(255) DEFAULT NULL,
  `thumbnail_url` text,
  `video_code` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `content_id` (`content_id`),
  CONSTRAINT `details_series_ibfk_1` FOREIGN KEY (`content_id`) REFERENCES `content` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `details_series` (`id`, `content_id`, `season_number`, `episode_number`, `title`, `summary`, `thumbnail_url`, `video_code`) VALUES
(27,	107,	1,	1,	'Pilot',	'Titans meeet each other for the first time.',	'http://localhost:8000/files/1666863632628.png',	'_cKIiQviCao'),
(28,	107,	1,	2,	'Back to the streets',	'Titans return to the streets of Ohio and look for the enemy.',	'http://localhost:8000/files/1666863703696.png',	'peeO4bwuPys'),
(29,	107,	1,	3,	'Major revenge',	'Titans are attacked by some strange creatures.',	'http://localhost:8000/files/1666863788870.png',	'6ttU1iKSpdA'),
(30,	108,	1,	1,	'Max meets Lisa',	'Tensions arise when Max starts seeing Lisa.',	'http://localhost:8000/files/1666864009413.png',	'7kIKGd6w6Y8'),
(31,	108,	1,	2,	'Linda goes wild',	'Linda turns out to have super powers...',	'http://localhost:8000/files/1666864065253.png',	'NUxwlnc5owM'),
(32,	108,	2,	1,	'New winds',	'The girls plan a party at a country house but who is invited...',	'http://localhost:8000/files/1666864135095.png',	'L71GcMnPnFA'),
(33,	108,	2,	2,	'What happened to Linda?',	'Linda is missing and nobody knows where she is...',	'http://localhost:8000/files/1666864203757.png',	'p7b4MkSAr9o'),
(34,	109,	1,	1,	'Where\'s the cash?',	'After a succesful robbing gig the cash is suddenly gone.',	'http://localhost:8000/files/1666864465440.png',	'bog5J_xsVmk'),
(35,	109,	1,	2,	'Cash smells',	'Jonny regrets robbing his relatives and wants to...',	'http://localhost:8000/files/1666864540100.png',	'yHFBsGdIBzs'),
(36,	109,	2,	1,	'The gang is back',	'The gang tries to solve their confilcts.',	'http://localhost:8000/files/1666864624686.png',	'6UBogcztd2A'),
(37,	109,	2,	2,	'Hard game',	'The fights escalate and Jonny needs to take a decision.',	'http://localhost:8000/files/1666864719792.png',	'o141_2Mj844'),
(38,	109,	2,	3,	'Promise',	'Jonny promises to never lie but the reality shows...',	'http://localhost:8000/files/1666864795911.png',	'vyTwo-TB7Ao');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `username` varchar(50) NOT NULL,
  `password` varchar(500) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `users` (`username`, `password`, `enabled`) VALUES
('edward@example.com',	'$2a$10$S7sXSbToit7lP4JlU4qZ7OAEA5kLWc5/Y3Zn.YlDcexZomPlSwI.i',	1),
('henry@example.com',	'$2a$10$DqDsfBZ/.g52zmNuq2.gjes9rOnDg3T76AqRxLlD2O30nHFUT.aR2',	1),
('max@example.com',	'$2a$10$VxNBPLOmJkzC/x79SySemejgxVKzJp/7qZUFF7IA63QIUEfG6CtOq',	1),
('mike@example.com',	'$2a$10$5dXQj9IwkyyCReUiOzz9HukW2mk28RCyMzu3BVap19jTwGKzO8vym',	1),
('sally@example.com',	'$2a$10$ELo5X6fiBbzmTjxowV9rmuCW/ss7OizOYEpRMR3fiCdQkJzffzdjG',	1),
('sheela@example.com',	'$2a$10$s8J9EKCHQ1bCV/piimpX/Ot3q32XpniLix7bzGSdSiB0yyGMhaD5S',	1);

-- 2022-10-28 10:17:04
